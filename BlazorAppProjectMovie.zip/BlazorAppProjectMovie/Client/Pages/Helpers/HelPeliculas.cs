﻿namespace BlazorAppProjectMovie.Client.Pages.Helpers
{

    public class HelPeliculas
    {
        public static string enmayuscula(string vale)
        {
            return (
                vale.ToUpper()
            );
        }
    }
}