﻿namespace BlazorAppProjectMovie.Client.Shared.Entidades
{
    public class Pelicula
    {
        public string Titulo { get; set; }
        public DateTime Fecha_de_lazanmiento { get; set; }
    }
}