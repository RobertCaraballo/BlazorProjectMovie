﻿namespace BlazorAppProjectMovie.Client
{

    public class ServiciosSingleton
    {
        public int valor { get; set; }
    }

    public class ServiciosTransistorio
    {
        public int valor { get; set; }
    }


}