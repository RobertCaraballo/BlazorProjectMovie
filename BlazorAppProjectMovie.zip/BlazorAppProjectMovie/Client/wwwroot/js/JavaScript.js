﻿function mostrarAlerta(mensaje) {
    return alert(mensaje);

